telnew => uniflair_sp_wm_mb_Telecom units
ug40cdz.mib=> uniflair_am_uniflair_le_amico_leonardo...
MSTAF_pCOWEB=> Master Control
invcdz => Inverter CRAC