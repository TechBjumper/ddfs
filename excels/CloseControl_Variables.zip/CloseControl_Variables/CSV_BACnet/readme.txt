telnew.csv => for Telecom Application, uniflair_sp_uniflair_wm_uniflair_mb

cdznew.csv => for uniflair_am_amico, for uniflair_le_leonardo

closecdz.csv => pCO5 controller

MSTAF_CSV_pCONEt => BACNet MS/TP

MSTAF_CSV_pCOWeb => BACNet Over IP

MSTMAF 1.7 IR33 Modbus_EN => CSV File for Master Control with IR33
