telecomunits.pdf => uniflair_sp_wm_mb_telecom

ug20_ug10_Mobus => Amico_Leonardo_pCOb controller

variables_ug40_mp40_en.xls => List of variables for uniflair_am_uniflair_le_amico_leonardo

variables_ug50_en.xls => List of variables for amico_leonardo with pCO5

MSTMAF.... => Master Control IR33 controller based