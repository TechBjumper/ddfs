--------------------------------------------------------------------------------
Liebert Global Products MIB
Version:    9.3_037834
Date:       Wed Oct 31 10:54:26 EDT 2007
Copyright <cp> 1999-2007 Liebert Corporation.  All Rights Reserved.
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
NOTE:
--------------------------------------------------------------------------------

Please consult the Quick Start Guide of your Liebert Power or Air Product for 
further information about using SNMP.  

The latest versions of User Manuals and MIBs are always available for download 
from www.liebert.com.


This distribution contains the MIB files used by most Liebert Products.

--------------------------------------------------------------------------------
INSTRUCTIONS FOR LOADING THE LIEBERT GLOBAL PRODUCTS MIB AND RFC1628 MIB:
--------------------------------------------------------------------------------

1)  Extract files from the zip/tar file (either 192436P1_Rev0.zip or 
    192435P1_Rev0.tar) to your NMS.

    This operation will yield nine individual MIB files and this readme.txt
    file.

2)  Load/compile the nine individual MIB files onto your NMS in 
    the following order:

    LIEBERT_GP_REG.MIB         (Load First)
    LIEBERT_GP_COND.MIB
    LIEBERT_GP_AGENT.MIB
    LIEBERT_GP_ENV.MIB
    LIEBERT_GP_NOTIFY.MIB
    LIEBERT_GP_CONTROLLER.MIB
    LIEBERT_GP_POWER.MIB       
    LIEBERT_GP_SYSTEM.MIB
    RFC1628_UPS_MIB.MIB        (Load Last)

    It is important that the MIB files be loaded in the correct
    order.
