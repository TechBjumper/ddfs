AQUASCROLL_LON
=> ERA_ISA_TRA series

AQUACENTR_LON
=> BCE_BCW series

AQUASCREW_LON
=> BRE series

ARANEW_LON
=> ARA series

BCHILSCROLL_LON
=> BRA series

BRWC_H_LON
=> BRW series

LRANEW
=> LRA series

